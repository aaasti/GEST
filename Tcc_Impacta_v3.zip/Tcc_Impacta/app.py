import os
from flask import Flask, json, render_template, request, jsonify, session
from flask_session import Session
from flaskext.mysql import MySQL
from werkzeug.security import generate_password_hash, check_password_hash

mysql = MySQL()
app = Flask(__name__)

# Session configurations
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
app.config["SESSION_FILE_DIR"] = "C:\session"
Session(app)


# MySQL configurations
app.config['MYSQL_DATABASE_USER'] = 'root'
app.config['MYSQL_DATABASE_PASSWORD'] = 'mudar123'
app.config['MYSQL_DATABASE_DB'] = 'tcc'
app.config['MYSQL_DATABASE_HOST'] = 'localhost'
mysql.init_app(app) 


# Rota para pagina inicial#   #
@app.route('/')
def main():
    if not session.get("name"):
        return render_template("home_login.html", msg1 = "Recuperar minha senha.")
    else:
        return render_template('home_principal.html')
    
@app.route('/logout')
def logout():
    session["name"] = None
    return render_template("home_login.html", msg1 = "Recuperar minha senha.")

# Rota para tela de reset de senha#  
@app.route('/reset')
def reset():
    return render_template("home_reset.html")

# Rota para recuepração de senha#  
@app.route('/emailsenha', methods=['POST','GET'])
def emailsenha():
    return render_template('home_login.html', msg1 ='Senha enviada para o e-mail de cadastro !!!')

# Rota para home#  
@app.route('/home', methods=['POST','GET'])
def home():
    if not session.get("name"):
        return render_template("home_login.html", msg1 = "Recuperar minha senha.")
    else:
        return render_template('home_principal.html')

# Rota para menu#  
@app.route('/menu', methods=['POST','GET'])
def menu():
    if not session.get("name"):
        return render_template("home_login.html", msg1 = "Recuperar minha senha.")
    else:
        return render_template('home_menu.html')

# Rota para autenticar usuario#  
@app.route('/logon', methods=['POST','GET'])
def logon():
  username = request.form['user']
  password = request.form['password']
  if Usuario.logarusuario(username, password) == 'OK':
      session["name"] = request.form['user']
      return render_template('home_principal.html')
  else:
    return render_template('home_login.html', msg1 = 'Credenciais inválidas.', msg2 = 'Recuperar a senha?')  

# Rota para cadastrar usuario#  
@app.route('/cadastra_usuario', methods=['POST','GET'])
def cadastra_usuario():
    if not session.get("name"):
        return render_template("home_login.html", msg1 = "Recuperar minha senha.")
    else:
        return render_template('usuario_novo.html')

# Rota para listar usuario#  
@app.route('/lista_usuarios', methods=['POST','GET'])
def lista_usuarios():
    if not session.get("name"):
        return render_template("home_login.html", msg1 = "Recuperar minha senha.")
    else:
        return render_template('usuario_lista.html', lista = Usuario.listarusuarios())

# Rota para pequisar usuario por nome, telefone e CPF#     
@app.route('/pesquisa_usuario', methods=['POST','GET'])
def pesquisa_usuario():
    if not session.get("name"):
        return render_template("home_login.html", msg1 = "Recuperar minha senha.")
    else:
        valor = request.form['nome']
        return render_template('usuario_lista.html', lista = Usuario.pesquisarusuario(valor))

# Rota para pesquisar usuário por Id#
@app.route('/usuario/<int:id_consulta>', methods=['POST','GET'])
def exibe_por_id(id_consulta):
    if not session.get("name"):
        return render_template("home_login.html", msg1 = "Recuperar minha senha.")
    else:  
        return render_template('usuario_edicao.html', datas = Usuario.pesquisarporid(id_consulta))

# Rota para atualizar usuario#
@app.route('/atualiza_usuario', methods=['POST','GET'])
def atualiza_usuario():
    password = request.form['senha']
    password = password.split('$')

    if password[0] == 'sha256':
        _hashed_password = request.form['senha']
    else:
        _hashed_password = generate_password_hash(request.form['senha'], method='sha256')
    
    id = request.form['id']
    nome = request.form['nome']
    username = request.form['user']
    password = _hashed_password
    email = request.form['email']
    cpf = request.form['cpf']
    telefone = request.form['telefone']

    if id and nome and username and password and email and cpf and telefone:
        registro_1 = Usuario(id,nome, username, password, email, cpf, telefone)
        registro_1.atualizarusuario()
        dado = Usuario.pesquisarporid(id)
        return render_template('usuario_edicao.html', datas = dado, msg = 'Usuário atualizado com sucesso')
    else:
        return render_template('usuario_edicao.html', datas = dado, msg = 'Preencha todos os campos obrigatórios')

# Rota para inserir novo usuario#
@app.route('/insere_usuario', methods=['POST','GET'])
def insere_usuario():
    id = "0"
    nome = request.form['nome']
    username = request.form['user']
    password = generate_password_hash(request.form['senha'], method='sha256')
    email = request.form['email']
    cpf = request.form['cpf']
    telefone = request.form['telefone']

    if id and nome and username and password and email and cpf and telefone:
        registro_1 = Usuario(id, nome, username, password, email, cpf, telefone)
        registro_1.inserirusuario()
        return render_template('usuario_novo.html', msg='Usuário inserido com sucesso')
    else:
        return render_template('usuario_novo.html', msg='Preencha todos os campos obrigatórios')

# Rota para cadastrar insumo novo insumo#
@app.route('/cadastra_insumo', methods=['POST','GET'])
def cadastra_insumo():
    if not session.get("name"):
        return render_template("home_login.html", msg1 = "Recuperar minha senha.")
    else:
        return render_template('insumo_novo.html')

# Rota para pesquisa insumo por nome, detalhe e codigo#
@app.route('/pesquisa_insumo', methods=['POST','GET'])
def pesquisa_insumo():
    if not session.get("name"):
        return render_template("home_login.html")
    else:
        valor = request.form['nome'] 
        if valor:
            return render_template('insumo_lista.html', lista = Insumo.pesquisar_insumo(valor))
        else:
            return render_template('insumo_lista.html', lista = Insumo.listar())  

# Rota para selecionar insumo por id #
@app.route('/insumo/<int:id_consulta>', methods=['POST','GET'])
def exibe_insumo_id(id_consulta):
    if not session.get("name"):
        return render_template("home_login.html")
    else:  
        insumo_id = id_consulta
        return render_template('insumo_edicao.html', datas= Insumo.pesquisar_insumo_id(insumo_id))

# Rota para atualizar insumo #
@app.route('/atualiza_insumo', methods=['POST','GET'])
def atualiza_insumo():
  id = request.form['id']
  nome = request.form['nome']
  detalhe = request.form['detalhe']
  unidade = request.form['unidade']
  preco = request.form['preco']
  dtpreco = request.form['data']

  try:
    situacao = request.form['situacao']
    situacao = 1
  except:
     situacao = 0

  if nome and detalhe and unidade and preco and dtpreco:
    registro_1 = Insumo(id,nome, detalhe, unidade, preco, dtpreco, situacao)
    dado = registro_1.atualizar_insumo()
    return render_template('insumo_edicao.html', datas = dado, msg = 'Insumo atualizado com sucesso')
  else:
    return render_template('insumo_edicao.html', msg = 'Insumo não atualizado')
  
# Lista relação de insumos #
@app.route('/lista_insumo', methods=['POST','GET'])
def lista_insumo():
        # check if the users exist or not
    if not session.get("name"):
        # if not there in the session then redirect to the login page
        return render_template("home_login.html")
    else:  
        return render_template('insumo_lista.html', lista = Insumo.listar())  

# Insere insumo na base #
@app.route('/insere_insumo', methods=['POST','GET'])
def insere_insumo():
  nome = request.form['nome']
  detalhe = request.form['detalhe']
  unidade = request.form['unidade']
  preco = request.form['preco']
  dtpreco = request.form['data']
  situacao = 1
 
  if nome and unidade and preco and dtpreco and situacao:
    registro_1 = Insumo(id,nome, detalhe, unidade, preco, dtpreco, situacao)
    registro_1.inserir_insumo()
    return render_template('insumo_novo.html', msg='Insumo inserido com sucesso')
  else:
    return render_template('insumo_novo.html', lista = Insumo.listar())

# Rota para lista de insumos no estoque#
@app.route('/lista_estoque', methods=['POST','GET'])
def lista_estoque():
    if not session.get("name"):
        return render_template("home_login.html", msg1 = "Recuperar minha senha.")
    else:
        return render_template('estoque_lista.html',lista = Estoque.listar_estoque())  

# Rota para pesquisa insumo por nome, detalhe e codigo#
@app.route('/pesquisa_estoque', methods=['POST','GET'])
def pesquisa_estoque():
    if not session.get("name"):
        return render_template("home_login.html")
    else:
        valor = request.form['nome'] 
        if valor:
            return render_template('estoque_lista.html', lista = Estoque.pesquisar_estoque(valor))
        else:
            return render_template('estoque_lista.html', lista = Estoque.listar_estoque())  

# Rota para selecionar insumo por id no estoque #
@app.route('/insumo_entrada/<int:id_consulta>', methods=['POST','GET'])
def exibe_insumo_entrada(id_consulta):
    if not session.get("name"):
        return render_template("home_login.html")
    else:  
        insumo_id = id_consulta
        return render_template('estoque_entrada.html', datas= Insumo.pesquisar_insumo_id(insumo_id))

# Rota para selecionar insumo por id no estoque #
@app.route('/insumo_saida/<int:id_consulta>', methods=['POST','GET'])
def exibe_insumo_saida(id_consulta):
    if not session.get("name"):
        return render_template("home_login.html")
    else:  
        insumo_id = id_consulta
        saldo = Estoque.consultar_sado(id_consulta)
        if saldo[0] <= 0:
             return render_template('estoque_lista.html',lista = Estoque.listar_estoque(), msg = 'Não é permitido movimento de saída com saldo 0' ) 
        else:
            return render_template('estoque_saida.html', datas= Insumo.pesquisar_insumo_id(insumo_id))
    
# Rota para selecionar insumo por id no estoque #
@app.route('/registra_entrada', methods=['POST','GET'])
def registra_insumo_entrada():
    if not session.get("name"):
        return render_template("home_login.html")
    else: 
        id_movimento = 0
        tipo_movimento = 1
        insumo_id = request.form['id']
        qtd_movimento = int(request.form['quantidade'])
        data_movimento = request.form ['data']
        usu_solicitante = session.get("name")

        if tipo_movimento and insumo_id and qtd_movimento and data_movimento and usu_solicitante or qtd_movimento > 0:
            registro_1 = Estoque(id_movimento,tipo_movimento, insumo_id, qtd_movimento, data_movimento, usu_solicitante)
            registro_1.registrar_movimento()
            return render_template('estoque_lista.html', lista = Estoque.listar_estoque(), msg = 'Entrada registrada com sucesso')
        else:
            return render_template('estoque_entrada.html', datas= Insumo.pesquisar_insumo_id(insumo_id), msg = 'Entrada não registrada, por favor revise o preenchimento')
  
# Rota para selecionar insumo por id no estoque #
@app.route('/registra_saida', methods=['POST','GET'])
def registra_insumo_saida():
    if not session.get("name"):
        return render_template("home_login.html")
    else:  
        id_movimento = 0
        tipo_movimento = 0
        insumo_id = request.form['id']
        qtd_movimento = -int(request.form['quantidade'])
        data_movimento = request.form ['data']
        usu_solicitante = session.get("name")
        saldo = Estoque.consultar_sado(insumo_id)

        if  insumo_id and qtd_movimento and data_movimento and usu_solicitante and saldo[0]>=int(request.form['quantidade']):
            registro_1 = Estoque(id_movimento,tipo_movimento, insumo_id, qtd_movimento, data_movimento, usu_solicitante)
            registro_1.registrar_movimento()
            return render_template('estoque_lista.html', lista = Estoque.listar_estoque(), msg = 'Saída registrada com sucesso')
        else:
            return render_template('estoque_saida.html', datas= Insumo.pesquisar_insumo_id(insumo_id), msg = 'Saída não registrada, por favor revise preenchimento')
  

class Usuario:
    def __init__(self, id, nome, username, password, email, cpf, telefone):
        self.id = id
        self.nome = nome
        self.username = username
        self.password = password
        self.email = email
        self.cpf = cpf
        self.telefone = telefone
    
    def logarusuario(username, password):
        query = "select user_password from tbl_user where user_username = '%s'" % (username)
        try:
            _hash_password = Banco.execute_selectone(query)
            if check_password_hash(_hash_password[0], password):
                return 'OK'
            else:
                return 'Credenciais inválidas'  
        except Exception as e:
            return 'Credenciais inválidas'
        finally:
            pass
    
    def listarusuarios():
        dado = Banco.execute_selectmany('select user_id, user_username, user_email, user_CPF, user_telefone from tbl_user')
        return dado
    
    def pesquisarusuario(valor):
        if valor != "":
            query = "select user_id, user_username, user_email, user_CPF, user_telefone from tbl_user where user_name like '%%%s%%'" % (valor)
            query = query + "union all select user_id, user_username, user_email, user_CPF, user_telefone from tbl_user where user_cpf like '%%%s%%'" % (valor)
            query = query + "union all select user_id, user_username, user_email, user_CPF, user_telefone from tbl_user where user_telefone like '%%%s%%'" % (valor)
            dado = Banco.execute_selectmany(query)
        else:
            dado = Usuario.listarusuarios()
        return dado
    
    def pesquisarporid(id):
        id = id
        query ='select * from tbl_user where user_id = ''%s' % (id)
        dado = Banco.execute_selectone(query)
        return dado
   
    def atualizarusuario(self):
        query = 'update tbl_user set user_name = "%s", user_username = "%s", user_password = "%s", user_email = "%s"' % (self.nome, self.username, self.password, self.email)
        query = query + ', user_cpf = "%s", user_telefone ="%s" where user_id = %s'% (self.cpf, self.telefone, self.id)
        Banco.execute_update(query)
        dado = Banco.execute_selectone('select * from tbl_user where user_id = ''%s' % (self.id))
        return dado

    def inserirusuario(self):
        query = 'insert into tbl_user (user_name, user_username, user_password, user_email, user_cpf, user_telefone) ' 
        query = query + 'VALUES ("%s", "%s", "%s", "%s", "%s", "%s")' % (self.nome, self.username, self.password, self.email, self.cpf, self.telefone)
        Banco.execute_insert(query)

class Insumo:
    def __init__(self, id, nome, detalhe, unidade, preco, dtpreco, situacao):
        self.id = id
        self.nome = nome
        self.detalhe = detalhe
        self.unidade = unidade
        self.preco = preco
        self.dtpreco = dtpreco
        self.situacao = situacao

    def listar():
        dado = Banco.execute_selectmany('select insumo_id, insumo_name, insumo_detalhe, insumo_unidade, insumo_preco, insumo_dtpreco, insumo_situacao from tbl_insumo')  
        return dado
    
    def pesquisar_insumo(valor):
        query = "select insumo_id, insumo_name, insumo_detalhe, insumo_unidade, insumo_preco, insumo_dtpreco, insumo_situacao from tbl_insumo where insumo_name like '%%%s%%'" % (valor)
        query = query + "union all select insumo_id, insumo_name, insumo_detalhe, insumo_unidade, insumo_preco, insumo_dtpreco, insumo_situacao from tbl_insumo where insumo_detalhe like '%%%s%%'" % (valor)
        query = query + "union all select insumo_id, insumo_name, insumo_detalhe, insumo_unidade, insumo_preco, insumo_dtpreco, insumo_situacao from tbl_insumo where insumo_unidade like '%%%s%%'" % (valor)
        dado = Banco.execute_selectmany(query)
        return dado
    
    def pesquisar_insumo_id(insumo_id):
        dado = Banco.execute_selectone('select * from tbl_insumo where insumo_id = ''%s' % (insumo_id))
        return dado
    
    def atualizar_insumo(self):
        query = 'update tbl_insumo set insumo_name = "%s", insumo_detalhe = "%s" , insumo_unidade = "%s", insumo_preco = %s' % (self.nome, self.detalhe, self.unidade, self.preco)
        query = query + ', insumo_dtpreco = "%s" , insumo_situacao = "%s" where insumo_id = %s' % (self.dtpreco, self.situacao, self.id)
        Banco.execute_update(query)

    def inserir_insumo(self):
        query = 'insert into tbl_insumo (insumo_name, insumo_detalhe, insumo_unidade, insumo_preco, insumo_dtpreco, insumo_situacao)'  
        query = query + ' VALUES ("%s","%s","%s",%s,"%s",%s)' % (self.nome, self.detalhe, self.unidade, self.preco, self.dtpreco, self.situacao)
        Banco.execute_insert(query)

class Banco:
    def __init__(self, query):
        self.query = query

    def execute_insert(query):
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute(query)
        conn.commit()
        
    def execute_update(query):
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute(query)
        conn.commit()

    def execute_selectall(query):
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute(query)
        dado = cursor.fetchall()
        conn.commit()
        return dado

    def execute_selectmany(query):
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute(query)
        dado = cursor.fetchmany(size=10)
        conn.commit()
        return dado

    def execute_selectone(query):
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute(query)
        dado = cursor.fetchone()
        conn.commit()
        return dado

class Estoque:
    def __init__(self, id_movimento, tipo_movimento, insumo_id, qtd_movimento, data_movimento, usu_solicitante):
        self.id_movimento = id_movimento
        self.tipo_movimento = tipo_movimento
        self.insumo_id = insumo_id
        self.qtd_movimento = qtd_movimento
        self.data_movimento = data_movimento
        self.usu_solicitante = usu_solicitante
          
    def listar_estoque():
        dado = Banco.execute_selectmany('select '
                                            ' a.insumo_id,'
                                            ' a.insumo_name,'
                                            ' a.insumo_detalhe,'
                                            ' a.insumo_unidade,'
                                            ' a.insumo_situacao,'
                                            ' case when '
                                               '     (select sum(b.qtd_movimento) from tbl_estoque b where b.insumo_id = a.insumo_id group by b.insumo_id) is Null Then 0 '
                                               '     ElSE (select sum(b.qtd_movimento) from tbl_estoque b where b.insumo_id = a.insumo_id group by b.insumo_id) END as saldo'
                                            ' from tbl_insumo a' 
                                            ' where a.insumo_situacao = 1'
                                            ' group by a.insumo_id')  
        return dado
    
    def pesquisar_estoque(valor):
        dado = Banco.execute_selectmany('select  a.insumo_id, '
                                               ' a.insumo_name, '
                                               ' a.insumo_detalhe, ' 
                                               ' a.insumo_unidade, '
                                               ' a.insumo_situacao, '
                                               ' case when '
                                               '     (select sum(b.qtd_movimento) from tbl_estoque b where b.insumo_id = a.insumo_id group by b.insumo_id) is Null Then 0 '
                                               '     ElSE (select sum(b.qtd_movimento) from tbl_estoque b where b.insumo_id = a.insumo_id group by b.insumo_id) END as saldo'
                                               ' from tbl_insumo a '
                                               ' where a.insumo_name like ''"%s"'
                                               ' and a.insumo_situacao = 1 ' % (valor))
        return dado

    def registrar_movimento(self):
        query = 'insert into tbl_estoque (tipo_movimento, insumo_id, qtd_movimento, data_movimento, usu_solicitante)'
        query = query + ' VALUES (%s,%s,%s,"%s","%s")' % (self.tipo_movimento, self.insumo_id, self.qtd_movimento, self.data_movimento, self.usu_solicitante)
        Banco.execute_insert(query)

    def consultar_sado(insumo_id):
        dado = Banco.execute_selectone( 'select case when '
                                               '     (select sum(b.qtd_movimento) from tbl_estoque b where b.insumo_id = a.insumo_id group by b.insumo_id) is Null Then 0 '
                                               '     ElSE (select sum(b.qtd_movimento) from tbl_estoque b where b.insumo_id = a.insumo_id group by b.insumo_id) END as saldo'
                                               ' from tbl_insumo a '
                                               ' where a.insumo_id = ''"%s"' % (insumo_id))
        return dado

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5008))
    app.run(host='0.0.0.0', port=port)

