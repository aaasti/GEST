
function geek2() {
    var result = confirm("Deseja excluir este usuário?");
    if (result == true) {
       return;
    } else {
        ;
    }
}
