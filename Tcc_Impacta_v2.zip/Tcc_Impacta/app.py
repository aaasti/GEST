import os
from flask import Flask, json, render_template, request, jsonify, session
from flask_session import Session
from flaskext.mysql import MySQL
from werkzeug.security import generate_password_hash, check_password_hash

mysql = MySQL()
app = Flask(__name__)

# Session configurations
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
app.config["SESSION_FILE_DIR"] = "C:\session"
Session(app)


# MySQL configurations
app.config['MYSQL_DATABASE_USER'] = 'root'
app.config['MYSQL_DATABASE_PASSWORD'] = 'mudar123'
app.config['MYSQL_DATABASE_DB'] = 'tcc'
app.config['MYSQL_DATABASE_HOST'] = 'localhost'
mysql.init_app(app) 

class Banco:
    def __init__(self, query):
        self.query = query

    def execute_insert(query):
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute(query)
        conn.commit()
        
    def execute_update(query):
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute(query)
        conn.commit()

    def execute_selectall(query):
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute(query)
        dado = cursor.fetchall()
        conn.commit()
        return dado

    def execute_selectmany(query):
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute(query)
        dado = cursor.fetchmany(size=10)
        conn.commit()
        return dado

    def execute_selectone(query):
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.execute(query)
        dado = cursor.fetchone()
        conn.commit()
        return dado

# Navegação da paginas #
@app.route('/')
def main():
    if not session.get("name"):
        return render_template("home_login.html", msg1 = "Recuperar minha senha.")
    else:
        return render_template('home_principal.html')
    
@app.route('/logout')
def logout():
    session["name"] = None
    return render_template("home_login.html", msg1 = "Recuperar minha senha.")

@app.route('/reset')
def reset():
    return render_template("home_reset.html")

@app.route('/emailsenha', methods=['POST','GET'])
def emailsenha():
    return render_template('home_login.html', msg1 ='Senha enviada para o e-mail de cadastro !!!')

@app.route('/home', methods=['POST','GET'])
def home():
    if not session.get("name"):
        return render_template("home_login.html", msg1 = "Recuperar minha senha.")
    else:
        return render_template('home_principal.html')

@app.route('/menu', methods=['POST','GET'])
def menu():
    if not session.get("name"):
        return render_template("home_login.html", msg1 = "Recuperar minha senha.")
    else:
        return render_template('home_menu.html')

@app.route('/logon', methods=['POST','GET'])
def logon():
  username = request.form['user']
  password = request.form['password']
  if Usuario.logarusuario(username, password) == 'OK':
      session["name"] = request.form['user']
      return render_template('home_principal.html')
  else:
    return render_template('home_login.html', msg1 = 'Credenciais inválidas.', msg2 = 'Recuperar a senha?')  

@app.route('/cadastra_usuario', methods=['POST','GET'])
def cadastra_usuario():
    if not session.get("name"):
        return render_template("home_login.html", msg1 = "Recuperar minha senha.")
    else:
        return render_template('usuario_novo.html')

  
@app.route('/lista_usuarios', methods=['POST','GET'])
def lista_usuarios():
    if not session.get("name"):
        return render_template("home_login.html", msg1 = "Recuperar minha senha.")
    else:
        return render_template('usuario_lista.html', lista = Usuario.listarusuarios())
     
@app.route('/pesquisa_usuario', methods=['POST','GET'])
def pesquisa_usuario():
    if not session.get("name"):
        return render_template("home_login.html", msg1 = "Recuperar minha senha.")
    else:
        valor = request.form['nome']
        return render_template('usuario_lista.html', lista = Usuario.pesquisarusuario(valor))

@app.route('/usuario/<int:id_consulta>', methods=['POST','GET'])
def exibe_por_id(id_consulta):
    if not session.get("name"):
        return render_template("home_login.html", msg1 = "Recuperar minha senha.")
    else:  
        return render_template('usuario_edicao.html', datas = Usuario.pesquisarporid(id_consulta))

@app.route('/atualiza_usuario', methods=['POST','GET'])
def atualiza_usuario():
    password = request.form['senha']
    password = password.split('$')

    if password[0] == 'sha256':
        _hashed_password = request.form['senha']
    else:
        _hashed_password = generate_password_hash(request.form['senha'], method='sha256')
    
    id = request.form['id']
    nome = request.form['nome']
    username = request.form['user']
    password = _hashed_password
    email = request.form['email']
    cpf = request.form['cpf']
    telefone = request.form['telefone']

    if id and nome and username and password and email and cpf and telefone:
        registro_1 = Usuario(id,nome, username, password, email, cpf, telefone)
        dado = registro_1.atualizarusuario()
        return render_template('usuario_edicao.html', datas = dado, msg = 'Usuário atualizado com sucesso')
    else:
        return render_template('usuario_edicao.html', datas = dado, msg = 'Preencha todos os campos obrigatórios')

@app.route('/insere_usuario', methods=['POST','GET'])
def insere_usuario():
    id = "0"
    nome = request.form['nome']
    username = request.form['user']
    password = generate_password_hash(request.form['senha'], method='sha256')
    email = request.form['email']
    cpf = request.form['cpf']
    telefone = request.form['telefone']

    if id and nome and username and password and email and cpf and telefone:
        registro_1 = Usuario(id, nome, username, password, email, cpf, telefone)
        registro_1.inserirusuario()
        return render_template('usuario_novo.html', msg='Usuário inserido com sucesso')
    else:
        return render_template('usuario_novo.html', msg='Preencha todos os campos obrigatórios')


@app.route('/cadastra_insumo', methods=['POST','GET'])
def cadastra_insumo():
    if not session.get("name"):
        return render_template("home_login.html", msg1 = "Recuperar minha senha.")
    else:
        return render_template('insumo_novo.html')
   

# Pesquisa insumo por nome, detalhe e codigo#
@app.route('/pesquisa_insumo', methods=['POST','GET'])
def pesquisa_insumo():
    # check if the users exist or not
    if not session.get("name"):
        # if not there in the session then redirect to the login page
        return render_template("home_login.html")
    else:  
        nome = request.form['nome']
        if nome:
            query = "select insumo_id, insumo_name, insumo_detalhe, insumo_unidade, insumo_preco, insumo_dtpreco, insumo_situacao from tbl_insumo where insumo_name like '%%%s%%'" % (nome)
            query = query + "union all select insumo_id, insumo_name, insumo_detalhe, insumo_unidade, insumo_preco, insumo_dtpreco, insumo_situacao from tbl_insumo where insumo_detalhe like '%%%s%%'" % (nome)
            query = query + "union all select insumo_id, insumo_name, insumo_detalhe, insumo_unidade, insumo_preco, insumo_dtpreco, insumo_situacao from tbl_insumo where insumo_unidade like '%%%s%%'" % (nome)
            data = Banco.execute_selectmany(query)
            return render_template('insumo_lista.html', lista = data)
        else:
            return render_template('insumo_lista.html', lista = Insumo.listar())  

# Seleciona insumo por id #
@app.route('/insumo/<int:id_consulta>', methods=['POST','GET'])
def exibe_insumo_id(id_consulta):
        # check if the users exist or not
    if not session.get("name"):
        # if not there in the session then redirect to the login page
        return render_template("home_login.html")
    else:  
        insumo_id = id_consulta
        data = Banco.execute_selectone('select * from tbl_insumo where insumo_id = ''%s' % (insumo_id))
        return render_template('insumo_edicao.html', datas=data)

# Atualiza insumo na base #
@app.route('/atualiza_insumo', methods=['POST','GET'])
def atualiza_insumo():
  id = request.form['id']
  nome = request.form['nome']
  detalhe = request.form['detalhe']
  unidade = request.form['unidade']
  preco = request.form['preco']
  data = request.form['data']

  try:
    situacao = request.form['situacao']
    situacao = 1
  except:
     situacao = 0

  if nome and detalhe and unidade and preco and data:
    query = 'update tbl_insumo set insumo_name = "%s", insumo_detalhe = "%s" , insumo_unidade = "%s", insumo_preco = %s' % (nome, detalhe, unidade, preco)
    query = query + ', insumo_dtpreco = "%s" , insumo_situacao = "%s" where insumo_id = %s' % (data, situacao, id)
    Banco.execute_update(query)
    insumo_id = request.form['id']
    data = Banco.execute_selectone('select * from tbl_insumo where insumo_id = %s' % (insumo_id))
    return render_template('insumo_edicao.html', datas = data, msg = 'Insumo atualizado com sucesso')
  else:
    return render_template('insumo_edicao.html', msg = 'Insumo não atualizado')
  
# Lista relação de insumos #
@app.route('/lista_insumo', methods=['POST','GET'])
def lista_insumo():
        # check if the users exist or not
    if not session.get("name"):
        # if not there in the session then redirect to the login page
        return render_template("home_login.html")
    else:  
        return render_template('insumo_lista.html', lista = Insumo.listar())  

# Insere insumo na base #
@app.route('/insere_insumo', methods=['POST','GET'])
def insere_insumo():
  nome = request.form['nome']
  detalhe = request.form['detalhe']
  unidade = request.form['unidade']
  preco = request.form['preco']
  datacadastro = request.form['data']
  situacao = 1
 
  if nome and unidade and preco and datacadastro and situacao:
    Banco.execute_insert('insert into tbl_insumo (insumo_name, insumo_detalhe, insumo_unidade, insumo_preco, insumo_dtpreco, insumo_situacao) VALUES (%s,%s,%s,%s,%s,%s)', 
                   (nome, detalhe, unidade, preco, datacadastro, situacao))
    return render_template('insumo_novo.html', msg='Insumo inserido com sucesso')
  else:
    data = Banco.execute_selectmany('select insumo_id, insumo_name, insumo_detalhe, insumo_unidade, insumo_preco, insumo_dtpreco from tbl_insumo')
    return render_template('insumo_novo.html', lista = data)

class Usuario:
    def __init__(self, id, nome, username, password, email, cpf, telefone):
        self.id = id
        self.nome = nome
        self.username = username
        self.password = password
        self.email = email
        self.cpf = cpf
        self.telefone = telefone
    
    def logarusuario(username, password):
        username = request.form['user']
        password = request.form['password']
        query = "select user_password from tbl_user where user_username = '%s'" % (username)
        try:
            _hash_password = Banco.execute_selectone(query)
            if check_password_hash(_hash_password[0], password):
                return 'OK'
            else:
                return 'Credenciais inválidas'  
        except Exception as e:
            return 'Credenciais inválidas'
        finally:
            pass
    
    def listarusuarios():
        dado = Banco.execute_selectmany('select user_id, user_username, user_email, user_CPF, user_telefone from tbl_user')
        return dado
    
    def pesquisarusuario(valor):
        if valor != "":
            query = "select user_id, user_username, user_email, user_CPF, user_telefone from tbl_user where user_name like '%%%s%%'" % (valor)
            query = query + "union all select user_id, user_username, user_email, user_CPF, user_telefone from tbl_user where user_cpf like '%%%s%%'" % (valor)
            query = query + "union all select user_id, user_username, user_email, user_CPF, user_telefone from tbl_user where user_telefone like '%%%s%%'" % (valor)
            dado = Banco.execute_selectmany(query)
        else:
            dado = Usuario.listarusuarios()
        return dado
    
    def pesquisarporid(id):
        id = id
        query ='select * from tbl_user where user_id = ''%s' % (id)
        dado = Banco.execute_selectone(query)
        return dado
   
    def atualizarusuario(self):
        query = 'update tbl_user set user_name = "%s", user_username = "%s", user_password = "%s", user_email = "%s"' % (self.nome, self.username, self.password, self.email)
        query = query + ', user_cpf = "%s", user_telefone ="%s" where user_id = %s'% (self.cpf, self.telefone, self.id)
        Banco.execute_update(query)
        dado = Banco.execute_selectone('select * from tbl_user where user_id = ''%s' % (self.id))
        return dado

    def inserirusuario(self):
        query = 'insert into tbl_user (user_name, user_username, user_password, user_email, user_cpf, user_telefone) ' 
        query = query + 'VALUES ("%s", "%s", "%s", "%s", "%s", "%s")' % (self.nome, self.username, self.password, self.email, self.cpf, self.telefone)
        Banco.execute_insert(query)

class Insumo:
    def __init__(self, nome) -> None:
        self.nome = nome
    
    def listar():
        dado = Banco.execute_selectmany('select insumo_id, insumo_name, insumo_detalhe, insumo_unidade, insumo_preco, insumo_dtpreco, insumo_situacao from tbl_insumo')  
        return dado

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5008))
    app.run(host='0.0.0.0', port=port)

